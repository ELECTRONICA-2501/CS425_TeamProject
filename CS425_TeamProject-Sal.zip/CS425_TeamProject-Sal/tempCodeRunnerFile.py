

@app.route('/players', methods=['GET', 'POST'])